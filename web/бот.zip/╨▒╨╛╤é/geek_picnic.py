def ask_for_help(question_):
    '''Эта функция принимает строку с вопросом и возвращает
    True - если в вопросе встретились слова типа "гик пикник",
    False - в остальных случаях'''
    with open('help_words.txt', encoding='utf-8') as file:
        for line in file:
            line = line.replace('\n', '')
            if line in question_:  # смотрим, есть ли слова из этого корпуса в вопросе
                return True
        return False