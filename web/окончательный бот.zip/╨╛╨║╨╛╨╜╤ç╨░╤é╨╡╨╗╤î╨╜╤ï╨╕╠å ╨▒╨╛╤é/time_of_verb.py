import pymorphy2
from string import punctuation
morph = pymorphy2.MorphAnalyzer()


def define_time(question_):
    for sign in question_:
        if sign in punctuation:
            question_ = question_.replace(sign, '')
    words = question_.lower().split()
    for word in words:
        if 'VERB' in morph.parse(word)[0].tag:
            if 'past' in morph.parse(word)[0].tag:
                return 'past'
            elif 'futr' in morph.parse(word)[0].tag:
                return 'futr'
            elif 'pres' in morph.parse(word)[0].tag:
                return 'futr'
    return None
