from time_of_verb import define_time

def file_searcher(the_word, question_):
    list_of_question_words = ['какой', 'какая', 'какие', 'какое', 'когда', 'где', 'кто', 'почему', 'зачем', 'что', 'откуда', 'куда', 'который', 'которая', 'которое', 'которые', 'сколько', 'как']
    for i in list_of_question_words:
        if i == the_word and i != 'когда':
            filename = i + '.csv'
            break
        elif i == the_word and i == 'когда':
            filename = i + define_time(question_) + '.csv'
    return filename