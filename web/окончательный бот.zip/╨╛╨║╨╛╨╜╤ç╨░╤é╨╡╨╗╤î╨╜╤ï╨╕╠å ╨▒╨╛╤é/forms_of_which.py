import re
import pymorphy2
morph = pymorphy2.MorphAnalyzer()


def find_forms(question):
    words = question.lower().split()
    new_words = []
    for word in words:
        lemma = morph.parse(word)[0].normal_form
        print(lemma)
        p = '^(какой|который|кто|что)$'
        if re.search(p, lemma):
            new_words.append(lemma)
        elif word == 'кому' or word == 'ком':
            new_words.append('кто')
        elif word == 'чем':
            new_words.append('что')
        else:
            new_words.append(word)
    new_text = ' '.join(new_words)
    return new_text

