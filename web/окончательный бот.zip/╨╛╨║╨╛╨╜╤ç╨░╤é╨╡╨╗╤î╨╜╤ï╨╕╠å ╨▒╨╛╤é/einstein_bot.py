from typing import Any
import telebot
from telebot import types
import re, requests
from nlp import is_it_a_question_word
from txt_files_manager import file_searcher
from lemmas_and_synonyms import give_quote
from forms_of_which import find_forms
from geek_picnic import ask_for_help
from time_of_verb import define_time

token = '1151315588:AAEM1I6Go3NGKzcyBxW3plj1kgft_jpVZZ0'

bot = telebot.TeleBot(token)

def listen(message):
    for m in messages:
        if m.content_type == 'text':
            analyze(message)
        if m.content_type == 'command':
            callback_inline(call)

@bot.message_handler(commands=['start'])
def starting(message):
    keyboard = types.InlineKeyboardMarkup()
    callback_button = types.InlineKeyboardButton(text="info", callback_data="geek")
    keyboard.add(callback_button)
    bot.send_message(message.chat.id, "Привет! Я — Альберт Эйнштейн. Ты можешь задать мне любой вопрос, а я постараюсь на него ответить!", reply_markup=keyboard)
    bot.send_message(
        message.chat.id,
        'Когда будешь задавать свой вопрос, не забудь поставить "?", надеюсь, что тебе понравится общаться со мной!')


@bot.message_handler(content_types=['text'])
def analyze(message):
    question_ = str(message).lower()
    pattern = "'text':\s'(.*)',\s'entities"
    question_ = re.search(pattern, question_)
    question_ = question_.group(1)
    if ask_for_help(question_) == True:
        keyboard = telebot.types.InlineKeyboardMarkup()
        callback_button = telebot.types.InlineKeyboardButton(text="GEEK PICNIC FAQ", url="https://www.online.geekpicnic.me/faq")
        keyboard.add(callback_button)
        action_string = 'typing'
        bot.send_chat_action(message.chat.id, action_string)
        bot.send_message(message.chat.id, 'Обожаю GEEK PICNIC, но я на нем лишь гость! Если у тебя возникли вопросы по поводу организации мероприятия, ты можешь найти ответы здесь:', reply_markup=keyboard)
    else:
        question_ = find_forms(question_)
        result_analyzing = re.search(
            'какой|когда|где|кто|почему|зачем|что|откуда|куда|который|сколько|как',
            question_)
        if result_analyzing == None:
            bot.send_message(message.chat.id, give_quote(question_, 'lemmas.csv'))
        else:
            action_string = 'typing'
            bot.send_chat_action(message.chat.id, action_string)
            the_word = is_it_a_question_word(question_)
            if the_word == False:
                bot.send_message(message.chat.id, give_quote(question_, 'lemmas.csv'))
            else:
                filename = file_searcher(the_word, question_)
                bot.send_message(message.chat.id, give_quote(question_, filename))

@bot.callback_query_handler(func=lambda call: True)
def callback_inline(call):
    if call.data == "geek":
        keyboard = telebot.types.InlineKeyboardMarkup()
        callback_button = telebot.types.InlineKeyboardButton(text="GEEK PICNIC FAQ", url="https://www.online.geekpicnic.me/faq")
        keyboard.add(callback_button)
        action_string = 'typing'
        bot.send_chat_action(call.message.chat.id, action_string)
        msg = bot.send_message(call.message.chat.id, 'Обожаю GEEK PICNIC, но я на нем лишь гость! Если у тебя возникли вопросы по поводу организации мероприятия, ты можешь найти ответы здесь:', reply_markup=keyboard)
        bot.register_next_step_handler(msg, analyze)

def main():
    new_offset = 0
    print('launching...')


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        exit()
    bot.polling(none_stop=True, interval=0)