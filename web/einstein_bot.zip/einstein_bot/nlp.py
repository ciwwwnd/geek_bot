import stanza

stanza.download('ru')


def is_it_a_question_word(question_):
    nlp = stanza.Pipeline(
        lang='ru', processors='tokenize,mwt,pos,lemma,depparse')
    doc = nlp(question_)
    # print(*[f'id: {word.id}\tword: {word.text}\thead id: {word.head}\thead: {sent.words[word.head-1].text if word.head > 0 else "root"}\tdeprel: {word.deprel}' for sent in doc.sentences for word in sent.words], sep='\n')
    # doc.sentences[0].print_dependencies()
    question_words = ['какой', 'какая', 'какие', 'какое', 'когда', 'где', 'кто', 'почему', 'зачем',
                      'что', 'откуда', 'куда', 'который', 'которая', 'которое', 'которые', 'сколько', 'как']

    dict_ = {}
    for sent in doc.sentences:
        for word in sent.words:
            dict_.update({word.text: word.head})
    print(dict_)
    for i, j in dict_.items():
        i = i.lower()
        for n in question_words:
            if i == n:
                word_head = j
                the_word = i
                break
        break

    for k, l in dict_.items():
        if k == '?':
            question_head = l

    if word_head == question_head or word_head == 0:
        return the_word
    else:
        return False

