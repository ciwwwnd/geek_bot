from typing import Any
import telebot
from telebot import types
import requests
import re
import os
from nlp import is_it_a_question_word
from txt_files_manager import file_searcher
from lemmas_and_synonyms import give_quote

token = '1151315588:AAEM1I6Go3NGKzcyBxW3plj1kgft_jpVZZ0'

bot = telebot.TeleBot(token)

def listen(message):
    for m in messages:
        if m.content_type == 'text':
            analyze(message)
        if m.content_type == 'command':
            callback_inline(call)

@bot.message_handler(commands=['start'])
def starting(message):
    keyboard = types.InlineKeyboardMarkup()
    callback_button = types.InlineKeyboardButton(text="info", callback_data="geek")
    keyboard.add(callback_button)
    bot.send_message(message.chat.id, "Привет! Я — Альберт Эйнштейн. Ты можешь задать мне любой вопрос, а я постараюсь на него ответить!", reply_markup=keyboard)
    bot.send_message(
        message.chat.id,
        'Когда будешь задавать свой вопрос, не забудь поставить "?", надеюсь, что тебе понравится общаться со мной!')


@bot.message_handler(content_types=['text'])
def analyze(message):
    question_ = str(message).lower()
    pattern = "'text':\s'(.*)',\s'entities"
    question_ = re.search(pattern, question_)
    question_ = question_.group(1)
    result_analyzing = re.search('какой|какая|какие|какое|когда|где|кто|почему|зачем|что|откуда|куда|который|которая|которое|которые|сколько|как', question_)
    print(result_analyzing)
    if result_analyzing == None:
        bot.send_message(message.chat.id, 'Ты уверен, что это вопрос?')
    else:
        action_string = 'typing'
        bot.send_chat_action(message.chat.id, action_string)
        the_word = is_it_a_question_word(question_)
        if the_word == False:
            print('Нет вопросительных слов:(')
        else:
            action_string = 'typing'
            bot.send_chat_action(message.chat.id, action_string)
            filename = file_searcher(the_word)
            bot.send_message(message.chat.id,  give_quote(question_, filename))

 #           bot.register_next_step_handler(msg, analyze)

@bot.callback_query_handler(func=lambda call: True)
def callback_inline(call):
    if call.data == "geek":
        keyboard = telebot.types.InlineKeyboardMarkup()
        callback_button = telebot.types.InlineKeyboardButton(text="GEEK PICNIC FAQ", url="https://www.online.geekpicnic.me/faq")
        keyboard.add(callback_button)
        action_string = 'typing'
        bot.send_chat_action(call.message.chat.id, action_string)
        msg = bot.send_message(call.message.chat.id, 'Обожаю GEEK PICNIC, но я на нем лишь гость! Если у тебя возникли вопросы по поводу организации мероприятия, ты можешь найти ответы здесь:', reply_markup=keyboard)
        bot.register_next_step_handler(msg, analyze)

def main():
    new_offset = 0
    print('launching...')


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        exit()
    bot.polling(none_stop=True, interval=0)