import csv, random

def file_searcher(the_word):
    quotes = []
    list_of_question_words = ['какой', 'какая', 'какие', 'какое', 'когда', 'где', 'кто', 'почему', 'зачем', 'что', 'откуда', 'куда', 'который', 'которая', 'которое', 'которые', 'сколько', 'как']
    for i in list_of_question_words:
        if i == the_word:
            filename = i + '.csv'
            break
    return filename



